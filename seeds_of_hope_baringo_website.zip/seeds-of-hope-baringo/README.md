# Seeds of Hope Baringo website

This is a simple, mobile-friendly static website ready for GitHub Pages.

## Publish it on GitHub Pages

1. Sign in to https://github.com/
2. Open https://github.com/new
3. Create a repository named `seeds-of-hope-baringo` (Public is simplest for GitHub Pages).
4. Upload `index.html` from this folder and click **Commit changes**.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose branch **main** and folder **/(root)**, then click **Save**.
8. Wait a few minutes. GitHub will show your published website address in Settings → Pages.

Your address will usually look like:
`https://YOUR-GITHUB-USERNAME.github.io/seeds-of-hope-baringo/`

## Before sharing publicly

- Confirm the contact number and WhatsApp link are correct.
- Add an official email address.
- Add verified photos with permission from the people pictured.
- Add donation/payment details only after they are confirmed.
- Do not claim registration, partnerships, beneficiary totals or impact figures unless verified.

The page currently uses remote sample photos from Unsplash and needs an internet connection to display them.
